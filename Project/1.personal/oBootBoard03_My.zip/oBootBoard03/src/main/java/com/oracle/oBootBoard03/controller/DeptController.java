package com.oracle.oBootBoard03.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.oracle.oBootBoard03.dto.DeptDto;
import com.oracle.oBootBoard03.dto.PageRequestDTO;
import com.oracle.oBootBoard03.dto.PageResponseDTO;
import com.oracle.oBootBoard03.service.DeptService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/dept")
public class DeptController {
	private final DeptService deptService;
	
	@GetMapping("/list")
	public String list(PageRequestDTO pageRequestDTO, Model model) {
		PageResponseDTO<DeptDto> pageResponseDeptDTO = deptService.deptList(pageRequestDTO);
		
		// page Response
		model.addAttribute("deptList", pageResponseDeptDTO.getDtoList());
		model.addAttribute("page", pageResponseDeptDTO);
		
		return "dept/list";
	}
	
	@GetMapping("deptInForm")
	public String deptInForm() {
//		System.out.println("deptInForm Page");
		
		return "dept/deptInForm";
	}
	
	@PostMapping("saveDept")
	public String saveDept(DeptDto deptDto) {
		System.out.println("saveDept deptDto : " + deptDto);
		deptService.create(deptDto);
		
		return "dept/list";
	}
}
