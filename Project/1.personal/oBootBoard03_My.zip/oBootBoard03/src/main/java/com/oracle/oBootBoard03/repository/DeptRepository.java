package com.oracle.oBootBoard03.repository;

import java.util.List;

import com.oracle.oBootBoard03.domain.Dept;
import com.oracle.oBootBoard03.dto.DeptDto;
import com.oracle.oBootBoard03.dto.PageRequestDTO;

public interface DeptRepository {
	List<Dept> findAllDept();
	List<DeptDto> findPageDept(PageRequestDTO pageRequestDTO);
	Dept deptSave(Dept dept);
}
