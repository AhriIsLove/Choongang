package com.oracle.oBootBoard03.dto;

import lombok.Data;

@Data
public class Emp_PicDto {
    private int emp_no;
	private int order_num;
	private String pictures;
}
