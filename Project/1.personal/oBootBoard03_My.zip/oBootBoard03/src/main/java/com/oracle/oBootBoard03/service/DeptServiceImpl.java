package com.oracle.oBootBoard03.service;

import java.time.LocalDate;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.oracle.oBootBoard03.domain.Dept;
import com.oracle.oBootBoard03.dto.DeptDto;
import com.oracle.oBootBoard03.dto.PageRequestDTO;
import com.oracle.oBootBoard03.dto.PageResponseDTO;
import com.oracle.oBootBoard03.repository.DeptRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@Transactional
@RequiredArgsConstructor
public class DeptServiceImpl implements DeptService {
	private final DeptRepository deptRepository;
	private final ModelMapper modelMapper;

	@Override
	public int totalDept() {
		return deptRepository.findAllDept().size();
	}

	@Override
	public PageResponseDTO<DeptDto> deptList(PageRequestDTO pageRequestDTO) {
		List<DeptDto> deptDtos = deptRepository.findPageDept(pageRequestDTO);
		
		PageResponseDTO<DeptDto> pageResponseDeptDTO = PageResponseDTO.<DeptDto>withAll()
				.dtoList(deptDtos)
				.totalCount(totalDept())
				.pageRequestDTO(pageRequestDTO)
				.build();

		return pageResponseDeptDTO;
	}

	@Override
	public int create(DeptDto deptDto) {
		Dept dept = dtoToDept(deptDto);
		//동일한 dtoToEntity 기능
//		Dept dept = modelMapper(deptDto, Dept.class);
		
		
		deptRepository.deptSave(dept);
		
		return dept.getDept_code();
	}
	
	private Dept dtoToDept(DeptDto deptDto){
		Dept dept = Dept.builder()
				.dept_code(0)
				.dept_loc(deptDto.getDept_loc())
				.dept_name(deptDto.getDept_name())
				.dept_tel(deptDto.getDept_tel())
				.dept_cpatain(0)
				.dept_gubun(false)
				.in_date(LocalDate.now())
				.build();
				
		return dept;
	}
	
	private DeptDto deptToDTO(Dept dept){
		DeptDto deptDto = DeptDto.builder()
				.dept_code(dept.getDept_code())
				.dept_loc(dept.getDept_loc())
				.dept_name(dept.getDept_name())
				.dept_tel(dept.getDept_tel())
				.dept_cpatain(dept.getDept_cpatain())
				.dept_gubun(dept.isDept_gubun())
				.in_date(dept.getIn_date())
				.build();
				
		return deptDto;
	}
}
