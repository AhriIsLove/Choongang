package com.oracle.oBootBoard03.service;

import java.util.List;

import com.oracle.oBootBoard03.dto.DeptDto;
import com.oracle.oBootBoard03.dto.PageRequestDTO;
import com.oracle.oBootBoard03.dto.PageResponseDTO;

public interface DeptService {
	int totalDept();
	PageResponseDTO<DeptDto> deptList(PageRequestDTO pageRequestDTO);
	int create(DeptDto deptDto);
}
