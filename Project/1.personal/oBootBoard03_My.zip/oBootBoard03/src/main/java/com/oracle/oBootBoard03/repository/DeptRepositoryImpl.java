package com.oracle.oBootBoard03.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.oracle.oBootBoard03.domain.Dept;
import com.oracle.oBootBoard03.dto.DeptDto;
import com.oracle.oBootBoard03.dto.PageRequestDTO;

import jakarta.persistence.EntityManager;
import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class DeptRepositoryImpl implements DeptRepository {
	private final EntityManager entityManager;
	private final SqlSession session;

	@Override
	public List<Dept> findAllDept() {
		List<Dept> depts = entityManager.createQuery("SELECT d FROM Dept d WHERE dept_gubun = false", Dept.class)
				.getResultList();

		return depts;
	}

	@Override
	public List<DeptDto> findPageDept(PageRequestDTO pageRequestDTO) {
		List<DeptDto> deptDtoList = null;
		try {
			deptDtoList = session.selectList("findPageDept", pageRequestDTO);
		} catch (Exception e) {
			System.out.println("deptList fail");
		}
		
		return deptDtoList;
	}

	@Override
	public Dept deptSave(Dept dept) {
		try {
			entityManager.persist(dept);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}

		return dept;
	}
}
