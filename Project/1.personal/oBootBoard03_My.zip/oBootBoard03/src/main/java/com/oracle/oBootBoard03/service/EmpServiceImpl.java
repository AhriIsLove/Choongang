package com.oracle.oBootBoard03.service;

import java.util.List;

import com.oracle.oBootBoard03.dto.EmpDto;

public class EmpServiceImpl implements EmpService {

	@Override
	public int totalEmp() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<EmpDto> deptList(EmpDto empDto) {
		// TODO Auto-generated method stub
		return null;
	}
}
