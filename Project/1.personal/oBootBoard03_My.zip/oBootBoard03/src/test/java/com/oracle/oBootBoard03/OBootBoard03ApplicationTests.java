package com.oracle.oBootBoard03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OBootBoard03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
