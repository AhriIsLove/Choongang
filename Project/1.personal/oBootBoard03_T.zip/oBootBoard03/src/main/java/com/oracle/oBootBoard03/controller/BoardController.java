package com.oracle.oBootBoard03.controller;

import java.util.List;

import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.oracle.oBootBoard03.dto.BoardDto;
import com.oracle.oBootBoard03.dto.DeptDto;
import com.oracle.oBootBoard03.dto.EmpDto;
import com.oracle.oBootBoard03.service.BoardService;
import com.oracle.oBootBoard03.service.EmpService;
import com.oracle.oBootBoard03.service.Paging;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Controller
@RequiredArgsConstructor
@Log4j2
@RequestMapping("/board")
public class BoardController {
	
	private final BoardService boardService;
	private final EmpService empService;

	// SecurityFilterChain -> requestMatchers 정의와 겹치면 안됨
	@Secured({"ROLE_USER","ROLE_ADMIN","ROLE_MANAGER"})
	@GetMapping("/boardInForm")
	public String boardInForm(Model model) {
		System.out.println("board/boardInForm Strart...");
		List<EmpDto> empDtoList = empService.empAllList();

		model.addAttribute("empDtoList", empDtoList);

		return "board/boardInForm";
	}
	
	@PostMapping("boardWrite")
	public String boardWrite(BoardDto  boardDto) {
		System.out.println("board/boardWrite Strart...");
		System.out.println("board/boardWrite boardDto->"+boardDto);
		// 여러분의 Logic 
		int dept_code = boardService.boardWrite(boardDto);
		log.info("Save dept_code-->", dept_code);
		return "redirect:list";
	}
	
	@Secured({"ROLE_GUEST","ROLE_USER","ROLE_ADMIN","ROLE_MANAGER"})
	@GetMapping("/list")
	public String listPage(BoardDto  boardDto , Model model) {
		System.out.println("board/list Strart...");

		System.out.println("board/list Strart...");
		int totalCount = boardService.totalBoard();	
		System.out.println("1.BoardController list totalCount->"+totalCount);
		Paging page = new Paging(totalCount, boardDto.getCurrentPage());

		// Parameter deptDto --> Page만 추가 Setting
		boardDto.setStart(page.getStart());   // 시작시 1
		boardDto.setEnd(page.getEnd());       // 시작시 10 
		
		System.out.println("2. BoardController list boardDto->"+boardDto);
		List<BoardDto> boardDtoList = boardService.boardList(boardDto);
		System.out.println("3. BoardController list boardDtoList=>" + boardDtoList);
		// System.out.println("3. BoardController list boardDtoList.size()=>" + boardDtoList.size());

		model.addAttribute("totalCount", totalCount);
		model.addAttribute("boardDtoList" , boardDtoList);
		model.addAttribute("page"    , page);

		return "board/list";
	}
	
	@GetMapping("/boardDetail")
	public String boardDetail(BoardDto  boardDto, Model model) {
		System.out.println("BoardController board/deptDetail Start...");
		System.out.println("BoardController board/deptDetail boardDto->"+boardDto);
		BoardDto  boardRtnDto = boardService.getSingleBoard(boardDto.getBoard_no());
		model.addAttribute("boardDto", boardRtnDto);

		return "board/boardDetail";
	}
	
	@Secured({"ROLE_USER","ROLE_ADMIN","ROLE_MANAGER"})
	@GetMapping("/modifyForm")
	public String modifyForm(BoardDto  boardDto , Model model) {
		System.out.println("BoardController board/modifyForm Start...");
		System.out.println("BoardController board/modifyForm boardDto->"+boardDto);
		BoardDto  boardRtnDto = boardService.getSingleBoard(boardDto.getBoard_no());
		model.addAttribute("boardDto", boardRtnDto);

		return "board/boardModifyForm";
	}
	
	@PostMapping("update")
	public String boardUpdate(BoardDto  boardDto) {
		System.out.println("BoardController board/boardUpdate Strart...");
		System.out.println("BoardController board/boardUpdate boardDto->"+boardDto);
		// 여러분의 Logic 
		int boardUpdateCount = boardService.boardUpdate(boardDto);
		log.info("deptUpdate boardUpdateCount-->", boardUpdateCount);
		return "redirect:list"; 
		
	}	
	
	@GetMapping("/deleteBoard")
	public String deleteBoard(BoardDto  boardDto , Model model) {
		System.out.println("BoardController board/deleteBoard Start...");
		System.out.println("BoardController board/deleteBoard boardDto->"+boardDto);
		int delCount = boardService.deleteBoard(boardDto.getBoard_no());

		return "redirect:list";
	}


	@GetMapping("/replyForm")
	public String replyForm(BoardDto  boardDto , Model model) {
		System.out.println("BoardController board/replyForm Start...");
		System.out.println("BoardController board/replyForm boardDto->"+boardDto);
		BoardDto  boardRtnDto = boardService.getSingleBoard(boardDto.getBoard_no());
		
		List<EmpDto> empDtoList = empService.empAllList();

		model.addAttribute("boardDto", boardRtnDto);
		model.addAttribute("empDtoList", empDtoList);

		return "board/boardReplyForm";
	}
	
	@PostMapping("replyWrite")
	public String replyWrite(BoardDto  boardDto) {
		System.out.println("board/replyWrite Strart...");
		System.out.println("board/replyWrite deptDto->"+boardDto);
		// 여러분의 Logic 
		int dept_code = boardService.replyWrite(boardDto);
		log.info("Save dept_code-->", dept_code);
		return "redirect:list";
	}

}
