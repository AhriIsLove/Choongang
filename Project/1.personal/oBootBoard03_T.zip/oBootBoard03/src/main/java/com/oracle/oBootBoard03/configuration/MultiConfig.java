package com.oracle.oBootBoard03.configuration;

import org.apache.coyote.http11.AbstractHttp11Protocol;
import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.unit.DataSize;
import org.springframework.web.multipart.support.StandardServletMultipartResolver;

import jakarta.servlet.MultipartConfigElement;


// Tomcat에서 파일 업로드 크기 제한을 설정하기 위한 설정 클래스
// TomcatConnectorCustomizer를 사용하여 maxSwallowSize를 설정합니다.
// 이 설정은 Tomcat이 요청 본문에서 읽을 수 있는 최대 크기를 지정합니다.
//@Configuration
//public class MultiConfig {
//	@Bean
//	public MultipartConfigElement multipartConfigElement() {
//	    MultipartConfigFactory factory = new MultipartConfigFactory();
//	    factory.setMaxFileSize(DataSize.ofMegabytes(10));
//	    factory.setMaxRequestSize(DataSize.ofMegabytes(50));
//	    // 파일 크기 제한 설정
//	    factory.setFileSizeThreshold(DataSize.ofKilobytes(2));
//	    return factory.createMultipartConfig();
//	}
//
//    @Bean
//    public StandardServletMultipartResolver multipartResolver() {
//        return new StandardServletMultipartResolver();
//    }
//}
