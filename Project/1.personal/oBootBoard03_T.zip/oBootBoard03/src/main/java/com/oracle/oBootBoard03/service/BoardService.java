package com.oracle.oBootBoard03.service;

import java.util.List;

import com.oracle.oBootBoard03.dto.BoardDto;

public interface BoardService {
	int             totalBoard();
	List<BoardDto>  boardList(BoardDto boardDto);
	int             boardWrite(BoardDto boardDto);
	BoardDto        getSingleBoard(int board_no);
	int             boardUpdate(BoardDto boardDto);
	int            deleteBoard(int board_no);
	int             replyWrite(BoardDto boardDto);
}
