package com.oracle.oBootBoard03.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.oracle.oBootBoard03.dao.BoardDao;
import com.oracle.oBootBoard03.dto.BoardDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
@RequiredArgsConstructor
public class BoardServiceImpl implements BoardService {
	
	private final BoardDao boardDao;

	@Override
	public int totalBoard() {
		int totalBoardCnt = boardDao.totalBoard();
		System.out.println("BoardServiceImpl totalBoard totalBoardCnt->" + totalBoardCnt);
		return totalBoardCnt;
	}
	
	@Override
	public List<BoardDto> boardList(BoardDto boardDto) {
		 List<BoardDto> boardList = null;
		 System.out.println("EmpServiceImpl boardList Start..." );
		 boardList = boardDao.boardList(boardDto);
		 System.out.println("BoardServiceImpl boardList boardList.size()->" +boardList.size());
		 return boardList;
	}

	@Override
	public int boardWrite(BoardDto boardDto) {
		int result = 0;
		System.out.println("BoardServiceImpl boardWrite Start..." );
		result = boardDao.boardWrite(boardDto);
		return result;
	}

	@Override
	public BoardDto getSingleBoard(int board_no) {
		System.out.println("BoardServiceImpl detailBoard ...");
		BoardDto boardDto = boardDao.detailBoard(board_no);
		int read_count = boardDao.readCountUpdate(board_no);
		System.out.println("BoardServiceImpl detailBoard read_count->" + read_count);
		return boardDto;
	}

	@Override
	public int boardUpdate(BoardDto boardDto) {
		System.out.println("BoardServiceImpl boardUpdate ...");
		int updateCount = 0;
		updateCount = boardDao.boardUpdate(boardDto);
		return updateCount;
	}

	@Override
	public int deleteBoard(int board_no) {
		int delCount = 0;
		System.out.println("BoardServiceImpl delete Start..." );
		delCount =  boardDao.deleteBoard(board_no);
		return delCount;
		
	}

	@Override
	public int replyWrite(BoardDto boardDto) {
		int result = 0;
		System.out.println("BoardServiceImpl replyWrite Start..." );
		result = boardDao.replyWrite(boardDto);
		return result;
	}



}
