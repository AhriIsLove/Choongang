package com.oracle.oBootBoard03.security.user.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.oracle.oBootBoard03.domain.Account;
import com.oracle.oBootBoard03.dto.AccountDto;
import com.oracle.oBootBoard03.dto.EmpDto;
import com.oracle.oBootBoard03.security.user.repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {
	private final UserRepository userRepository;
	
	@Transactional
	public void createUser(Account account) {
		System.out.println("UserService createUser account->"+account);
		userRepository.save(account);
	}

	public Long totalAccount() {
		//	System.out.println("UserService totalAccount Start...");
        Long totalCount = userRepository.count();
		return totalCount;
	}

	public List<AccountDto> accountList(AccountDto accountDto) {
		List<AccountDto> accountRtnList = new ArrayList<>();
		
	    List<Object[]> accountObjList = userRepository.findPageAccountNative(accountDto.getStart(), accountDto.getEnd());
	    for (Object[] result : accountObjList) {
	    	AccountDto accountDtoTmp = new AccountDto();
	    	accountDtoTmp.setId(((Number)result[0]).longValue());
	    	accountDtoTmp.setUsername((String)result[1]);
	    	accountDtoTmp.setPassword((String)result[2]);
	    	accountDtoTmp.setRoles((String)result[3]);
	    	accountDtoTmp.setAge(((Number)result[4]).intValue());
	    	
	    	accountRtnList.add(accountDtoTmp);
	    }
	    System.out.println("UserService accountList accountRtnList->"+accountRtnList);	
	    
	    return accountRtnList;
	}

}
