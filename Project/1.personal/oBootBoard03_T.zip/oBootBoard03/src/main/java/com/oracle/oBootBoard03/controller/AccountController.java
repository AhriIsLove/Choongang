package com.oracle.oBootBoard03.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.oracle.oBootBoard03.domain.Account;
import com.oracle.oBootBoard03.dto.AccountDto;
import com.oracle.oBootBoard03.security.user.service.UserService;
import com.oracle.oBootBoard03.service.Paging;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Controller
@RequiredArgsConstructor
@Log4j2
@RequestMapping("/account")
@PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
public class AccountController {

	private final UserService userService;
	private final PasswordEncoder passwordEncoder;
	
	@GetMapping("/accountInForm")
	public String accountInForm(Model model) {
		System.out.println("account/accountInForm Strart...");
		return "account/accountInForm";
	}
	
	@PostMapping(value = "/accountSignup")
	public String signup(AccountDto accountDto) {
		System.out.println("UserController @PostMapping signup start... ");
		System.out.println("UserController @PostMapping signup accountDto 1->"+accountDto);
		ModelMapper mapper = new ModelMapper();
		Account account = mapper.map(accountDto, Account.class);
		// accountDto password Encoder
		account.setPassword(passwordEncoder.encode(accountDto.getPassword()));
		System.out.println("UserController @PostMapping signup accountDto 2->"+accountDto);
		userService.createUser(account);
	
		return "redirect:list";

	}
	
	@GetMapping("/list")
	public String listPage(AccountDto accountDto , Model model) {
		System.out.println("dept/list Strart...");
		Long totalCountLong =  userService.totalAccount();	
		int totalCountInt = totalCountLong.intValue(); 
		System.out.println("1.DeptController list totalCount->"+totalCountInt);
		Paging page = new Paging(totalCountInt, accountDto.getCurrentPage());

		// Parameter deptDto --> Page만 추가 Setting
		accountDto.setStart(page.getStart());   // 시작시 1
		accountDto.setEnd(page.getEnd());       // 시작시 10 
		
		System.out.println("2. AccountController list accountDto->"+accountDto);
		List<AccountDto> accountDtoList = userService.accountList(accountDto);
		System.out.println("3. DeptController list listDept.size()=>" + accountDtoList.size());

		model.addAttribute("totalCount", totalCountInt);
		model.addAttribute("accountDtoList" , accountDtoList);
		model.addAttribute("page"    , page);

		return "account/list";
	}
}
