package com.oracle.oBootBoard03.domain;

import java.io.Serializable;

import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import lombok.Data;

// Serializable 사용이유 
// 웹 애플리케이션에서 사용자 세션 정보를 안전하게 관리하고, 
// 서버 재시작이나 클러스터 환경에서도 세션이 유지될 수 있도록 하기 위함
@Entity
@Data
@SequenceGenerator(
		name = "account_seq_gen",  // Seq 객체
		sequenceName = "account_seq_generator", // Seq DB 
		initialValue = 1,
		allocationSize = 1
  )
public class Account implements Serializable {
	@Id
	@GeneratedValue(
			 strategy = GenerationType.SEQUENCE,
			 generator = "account_seq_gen"
	)
    private Long    id;
    private String username;
    private String password;
    private String roles;
    private int age;

}
