package com.oracle.oBootBoard03.dao;

import java.util.List;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.oracle.oBootBoard03.dto.BoardDto;
import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class BoardDaoImpl implements BoardDao {

	private final PlatformTransactionManager transactionManager;

	private final SqlSession session;
	

	@Override
	public int totalBoard() {
		int totBoardCount = 0;
		System.out.println("BoardDaoImpl Start totalEmp..." );
		
		try {
			totBoardCount = session.selectOne("boardTotal");
			System.out.println("BoardDaoImpl totalBoard totBoardCount->" +totBoardCount);
			
		} catch (Exception e) {
			System.out.println("BoardDaoImpl totalBoard e.getMessage()->"+e.getMessage());
		}
		
		return totBoardCount;
	}


	@Override
	public List<BoardDto> boardList(BoardDto boardDto) {
		List<BoardDto> boardList = null;
		System.out.println("BoardDaoImpl boardList Start ..." );
		try {
			//                             Map ID        parameter
			boardList = session.selectList("tkBoardListAll", boardDto);
			System.out.println("BoardDaoImpl boardList boardList.size()->"+boardList.size());
			
		} catch (Exception e) {
			System.out.println("BoardDaoImpl boardList e.getMessage()->"+e.getMessage());
		}
		return boardList;
	}

	@Override
	public int boardWrite(BoardDto boardDto) {
		int result = 0;
		System.out.println("BoardDaoImpl boardWrite Start..." );
		try {
			// System 기본 Setting 값
			boardDto.setRead_count(0);
			boardDto.setRe_lvl(0);
			boardDto.setRe_step(0);
			result = session.insert("boardWrite",boardDto);
		} catch (Exception e) {
			System.out.println("BoardDaoImpl boardWrite Exception->"+e.getMessage());
		}
		return result;
	}


	@Override
	public BoardDto detailBoard(int board_no) {
		System.out.println("EmpDaoImpl detail start..");
		System.out.println("EmpDaoImpl detail board_no->"+board_no);
		BoardDto boardDto= new BoardDto();
		//		2. BoardDaoImpl   detailBoard  method 선언 
		//                        mapper ID   ,    Parameter
		try {
			//                              mapper ID   ,    Parameter
			boardDto = session.selectOne("tkBoardSelOne",    board_no);
			System.out.println("BoardDaoImpl detailBoard boardDto->"+boardDto);
		} catch (Exception e) {
			System.out.println("BoardDaoImpl detailBoard Exception->"+e.getMessage());
		}
		return boardDto;
	}


	@Override
	public int boardUpdate(BoardDto boardDto) {
		System.out.println("BoardDaoImpl boardUpdate start..");
		int updateCount= 0;
		try {
			updateCount = session.update("tkBoardUpdate",boardDto);
		} catch (Exception e) {
			System.out.println("BoardDaoImpl boardUpdate Exception->"+e.getMessage());
		}
		return updateCount;
	}


	@Override
	public int deleteBoard(int board_no) {
		System.out.println("BoardDaoImpl deleteBoard start..");
		int delCount = 0;
		System.out.println("BoardDaoImpl deleteBoard board_no->"+board_no);
		try {
			delCount  = session.delete("deleteBoard",board_no);
			System.out.println("BoardDaoImpl deleteBoard delCount->"+delCount);
		} catch (Exception e) {
			System.out.println("BoardDaoImpl deleteBoard Exception->"+e.getMessage());
		}

		// TODO Auto-generated method stub
		return delCount;
	}


	@Override
	public int replyWrite(BoardDto boardDto) {
		int result = 0;
		System.out.println("BoardDaoImpl replyWrite Start..." );
		TransactionStatus txStatus = 
				transactionManager.getTransaction(new DefaultTransactionDefinition());

		try {
			// 홍해 기적 
			replyShape(boardDto);

			// System 기본 Setting 값
			boardDto.setRead_count(0);
			// 기본적으로 댓글이기에 하나씩 ++ -> setRe_lvl , setRe_step
			boardDto.setRe_lvl(boardDto.getRe_lvl()+1);
			boardDto.setRe_step(boardDto.getRe_step()+1);
			result = session.insert("boardReplyWrite",boardDto);
			transactionManager.commit(txStatus);
		} catch (Exception e) {
	    	transactionManager.rollback(txStatus);
			System.out.println("BoardDaoImpl boardWrite Exception->"+e.getMessage());
		}
		return result;
	}


	private void replyShape(BoardDto boardDto) {
		System.out.println("BoardDaoImpl replyShape start..");
		int updateCount= 0;
		try {
			updateCount = session.update("tkReplyShapeUpdate",boardDto);
		} catch (Exception e) {
			System.out.println("BoardDaoImpl replyShape Exception->"+e.getMessage());
		}
		
	}


	@Override
	public int readCountUpdate(int board_no) {
		System.out.println("BoardDaoImpl readCountUpdate start..");
		int updateCount= 0;
		try {
			updateCount = session.update("tkReadCountUpdate",board_no);
		} catch (Exception e) {
			System.out.println("BoardDaoImpl replyShape Exception->"+e.getMessage());
		}
		return updateCount;
	}


}
