package com.oracle.oBootBoard03.security.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.oracle.oBootBoard03.domain.Account;
import com.oracle.oBootBoard03.dto.AccountContext;
import com.oracle.oBootBoard03.dto.AccountDto;
import com.oracle.oBootBoard03.security.user.repository.UserRepository;


import lombok.RequiredArgsConstructor;

@Service("userDetailService")
@RequiredArgsConstructor
//UserDetails: Spring Security에서 사용자의 정보를 담는 인터페이스
//UserDetailsService: Spring Security에서 유저의 정보를 가져오는 인터페이스
public class FormUserDetailsService implements UserDetailsService {

	private final UserRepository userRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Account account = userRepository.findByUsername(username);

		List<GrantedAuthority> authorities = List.of(new SimpleGrantedAuthority(account.getRoles()));
		ModelMapper mapper = new ModelMapper();
		AccountDto accountDto = mapper.map(account, AccountDto.class);
        System.out.println("FormUserDetailsService loadUserByUsername accountDto->"+accountDto);
        System.out.println("FormUserDetailsService loadUserByUsername authorities->"+authorities);
		
		
		
		return new AccountContext(accountDto, authorities);
	}

}
