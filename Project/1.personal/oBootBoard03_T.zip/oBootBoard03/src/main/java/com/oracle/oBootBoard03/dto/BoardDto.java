package com.oracle.oBootBoard03.dto;

import java.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class BoardDto {
	private int board_no;
	private String title;
	private String content;
	private int emp_no;
	private int read_count;
	private int ref;
	private int re_lvl;
	private int re_step;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate in_date;
	
	// 조회용
	private String      pageNum;  
	private int 		start; 		 	   
	private int 		end;
	private String      currentPage;
	private String      emp_name;

}
