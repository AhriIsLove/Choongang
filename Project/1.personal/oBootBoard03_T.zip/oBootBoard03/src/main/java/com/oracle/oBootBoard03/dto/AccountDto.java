package com.oracle.oBootBoard03.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AccountDto {
	   private Long   	id;
	   private String 	username;
	   private String 	password;
	   private int 		age;
	   private String 	roles;

		// 조회용
		private String      pageNum;  
		private int 		start; 		 	   
		private int 		end;
		private String      currentPage;

		// 2. 엔티티 객체를 받아서 DTO로 변환하는 생성자 (더 편리!)
		public AccountDto(int Long, String username, String password, String roles, int age) {
			this.id = id;
			this.username = username;
			this.password = password;
			this.roles = roles;
			this.age = age;
		}
}
