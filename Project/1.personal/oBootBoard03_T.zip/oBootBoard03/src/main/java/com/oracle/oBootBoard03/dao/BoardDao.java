package com.oracle.oBootBoard03.dao;

import java.util.List;

import com.oracle.oBootBoard03.dto.BoardDto;

public interface BoardDao {
	int            boardWrite(BoardDto boardDto);
	int            totalBoard();
	List<BoardDto> boardList(BoardDto boardDto);
	BoardDto       detailBoard(int board_no);
	int            boardUpdate(BoardDto boardDto);
	int            deleteBoard(int board_no);
	int            replyWrite(BoardDto boardDto);
	int            readCountUpdate(int board_no);
}
