package com.oracle.oBootBoard03.repository;

import java.util.List;
import java.util.Optional;

import com.oracle.oBootBoard03.domain.Emp;
import com.oracle.oBootBoard03.dto.DeptDto;
import com.oracle.oBootBoard03.dto.EmpDto;

public interface EmpRepository {
//	List<EmpDto> 	findAllEmp();
	Emp         	empSave(Emp emp);
	Long        	empTotalcount();
	List<EmpDto> 	findPageEmp(EmpDto empDto);
	EmpDto          findById(int emp_no);
	Optional<Emp>   findById2(int emp_no);
	void            deleteById(int emp_no);
	List<EmpDto>    findAllEmp();
	Optional<Emp>   findByEmpId(String emp_id);
	
}
