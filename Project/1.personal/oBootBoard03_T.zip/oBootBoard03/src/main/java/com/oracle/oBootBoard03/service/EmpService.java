package com.oracle.oBootBoard03.service;

import java.util.List;

import com.oracle.oBootBoard03.dto.EmpDto;

public interface EmpService {
	Long 			totalEmp();
	List<EmpDto>	empList(EmpDto empDto);
	int             register(EmpDto empDto);
	EmpDto          getSingleEmp(int emp_no);
	EmpDto          empUpdate(EmpDto empDto);
	void            deleteEmp(int emp_no);
	List<EmpDto>    empAllList();
	EmpDto          empLoginUpdate(EmpDto empDto);
	String          checkEmpId(String emp_id);
	
	
}
