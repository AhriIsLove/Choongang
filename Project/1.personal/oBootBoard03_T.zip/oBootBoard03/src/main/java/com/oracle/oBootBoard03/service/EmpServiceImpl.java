package com.oracle.oBootBoard03.service;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oracle.oBootBoard03.domain.Dept;
import com.oracle.oBootBoard03.domain.Emp;
import com.oracle.oBootBoard03.dto.DeptDto;
import com.oracle.oBootBoard03.dto.EmpDto;
import com.oracle.oBootBoard03.repository.EmpRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
@RequiredArgsConstructor
@Transactional
public class EmpServiceImpl implements EmpService {
	
	//자동주입 대상은 final로 
    private final  ModelMapper modelMapper;
	private final  EmpRepository empRepository;

	@Override
	public Long totalEmp() {
		System.out.println("EmpServiceImpl dept/list Strart...");
		Long totalCount =  empRepository.empTotalcount();
		return totalCount;
	}

	@Override
	public List<EmpDto> empList(EmpDto empDto) {
	    List<EmpDto> empRtnList = empRepository.findPageEmp(empDto);
	    System.out.println("EmpServiceImpl deptList empRtnList->"+empRtnList);	
	    return empRtnList;
	}

	@Override
	public int register(EmpDto empDto) {
		Emp emp = dtoToEntity(empDto);
		System.out.println("EmpServiceImpl register emp->"+emp);
		Emp saveEmp = empRepository.empSave(emp);
		return saveEmp.getEmp_no();
	}

	private Emp dtoToEntity(EmpDto empDto) {
		// Build 사용이유 : 유지보수 용이 
		// 1. 많은 필드(특히 선택적 필드 많을 때)
		// 2. 객체 생성 과정이 복잡할 때
		// 3. 가독성(불변 객채)
		// 간단 객체 --> 생성자
		Emp emp = Emp.builder()
					 .emp_id(empDto.getEmp_id())
					 .emp_password(empDto.getEmp_password())
					 .emp_name(empDto.getEmp_name())
					 .email(empDto.getEmail())
					 .emp_tel(empDto.getEmp_tel())
					 .sal(empDto.getSal())
					 .del_status(empDto.getDel_status())
					 .dept_code(empDto.getDept_code())
					 .emp_level(empDto.getEmp_level())
					 .in_date(empDto.getIn_date())
					 .build()
				  ;
		
		// 업로드 처리가 끝난 파일들의 이름 리스트 
		List<String> uploadfileNames = empDto.getUploadFileNames();
		System.out.println("EmpServiceImpl register uploadfileNames->"+uploadfileNames);

		if(uploadfileNames == null || uploadfileNames.isEmpty())  return emp;
		
		// Entity에게 uploadName명 넘겨줌  --> List<Emp> imageList 누적 
		uploadfileNames.stream()
					   .forEach(uploadfileName->{
						   			emp.addImageString(uploadfileName);
					   			}
					   );	
	
		return emp;
	}

	@Override
	public EmpDto getSingleEmp(int emp_no) {
		EmpDto empDto = empRepository.findById(emp_no);
		System.out.println("EmpServiceImpl getSingleEmp empDto->"+empDto);
		
		return empDto;
	}

	@Override
	public EmpDto empUpdate(EmpDto changeEmpDto) {
		
		Optional<Emp> maybeEmp = empRepository.findById2(changeEmpDto.getEmp_no());
		Emp emp = maybeEmp.orElseThrow();
		Emp empUpdate = changeUpdateEmp(emp, changeEmpDto);


	    Emp    empUpdateEntity = empRepository.empSave(empUpdate);
	    EmpDto empRtnDto = modelMapper.map(empUpdateEntity, EmpDto.class );
		return empRtnDto;
	}

	private Emp changeUpdateEmp(Emp emp, EmpDto changeEmpDto) {
		emp.changeEmpId(changeEmpDto.getEmp_id());
		emp.changeEmp_password(changeEmpDto.getEmp_password());
		emp.changeEmp_name(changeEmpDto.getEmp_name());
		emp.changeEmail(changeEmpDto.getEmail());
		emp.changeEmp_tel(changeEmpDto.getEmp_tel());
		emp.changeDept_code(changeEmpDto.getDept_code());
		emp.changeSal(changeEmpDto.getSal());
		// 업로드 처리가 끝난 파일들의 이름 리스트 
		List<String> uploadfileNames = changeEmpDto.getUploadFileNames();
		System.out.println("EmpServiceImpl changeUpdateEmp uploadfileNames->"+uploadfileNames);

		if(uploadfileNames == null || uploadfileNames.isEmpty())  return emp;
		
		// file 정리후 진행 
		emp.clearList();
		
		// Entity에게 uploadName명 넘겨줌  --> List<Emp> imageList 누적 
		uploadfileNames.stream()
					   .forEach(uploadfileName->{
						   			emp.addImageString(uploadfileName);
					   			}
					   );	

	    System.out.println("EmpServiceImpl changeUpdateEmp emp->"+emp);
		return emp;
	}

	@Override
	public void deleteEmp(int emp_no) {
	    System.out.println("EmpServiceImpl deleteEmp emp_no->"+emp_no);
	    empRepository.deleteById(emp_no);
	    return;
	}

	@Override
	public List<EmpDto> empAllList() {
	    List<EmpDto> empRtnList = empRepository.findAllEmp();
	    System.out.println("EmpServiceImpl deptList empRtnList->"+empRtnList);	
	    return empRtnList;
	}

	// Emp 중의  Login 부분만 수정 
	@Override
	public EmpDto empLoginUpdate(EmpDto empDto) {
		Optional<Emp> maybeEmp = empRepository.findById2(empDto.getEmp_no());
		Emp emp = maybeEmp.orElseThrow();
		emp.changeEmpId(empDto.getEmp_id());
		emp.changeEmp_password(empDto.getEmp_password());
	    Emp    empUpdateEntity = empRepository.empSave(emp);
	    EmpDto empRtnDto = modelMapper.map(empUpdateEntity, EmpDto.class );
		return empRtnDto;
	}

	@Override
	public String checkEmpId(String emp_id) {
		 String[] isPresentCheck = {""}; // 배열로 만들어서 람다 내에서 수정 가능하게
		    
		    Optional<Emp> maybeEmp = empRepository.findByEmpId(emp_id);
		    maybeEmp.ifPresentOrElse(
			        emp -> isPresentCheck[0] = "1", // 존재하면 중복
			        () -> isPresentCheck[0] = "0"   // 존재하지 않으면 중복 아님
		    );
            System.out.println("JpaMemberRepository findByEmpId isPresentCheck[0]->"+isPresentCheck[0]);	    
		    return isPresentCheck[0];
	}

	
	

}
