package com.oracle.oBootBoard03.controller;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import com.oracle.oBootBoard03.dto.DeptDto;
import com.oracle.oBootBoard03.dto.EmpDto;
import com.oracle.oBootBoard03.service.DeptService;
import com.oracle.oBootBoard03.service.EmpService;
import com.oracle.oBootBoard03.service.Paging;
import com.oracle.oBootBoard03.util.CustomFileUtil;


import lombok.RequiredArgsConstructor;

import lombok.extern.log4j.Log4j2;


@Controller
@RequiredArgsConstructor
@Log4j2
@RequestMapping("/emp")
public class EmpController {
	
	private final EmpService empService;
	private final DeptService deptService;
	private final CustomFileUtil fileUtil;
	
//	@GetMapping("/list")
//	public String mainPage() {
//		System.out.println("emp/list Strart...");
//		return "emp/list";
//	}
	
	@GetMapping("/empInForm")
	public String empInForm(Model model) {
		System.out.println("emp/empInForm Strart...");
		// 부서선택을 combo Box로 제공하기 위함 
		List<DeptDto> deptDtoList = deptService.deptAllList();
		System.out.println("3. DeptController list listDept.size()=>" + deptDtoList.size());

		model.addAttribute("deptDtoList", deptDtoList);

		return "emp/empInForm";
	}

	@RequestMapping("/saveEmp")
	public String saveEmp( 
			        EmpDto empDto ,
			        //@RequestParam("files") List<MultipartFile> files,
			        // @RequestParam(value = "files", required = false) MultipartFile[] files,  // List 대신 배열로 받기
			        Model model) 
		     {
	    System.out.println("saveEmp file start...");

	    // List<MultipartFile> filesList = Arrays.asList(files);
	    List<MultipartFile> files = empDto.getFiles();

	    log.info("1. rgister empDto:" + empDto);
	    // File Upload
	    List<String> uploadFileNames = fileUtil.saveFiles(files);
	    empDto.setUploadFileNames(uploadFileNames);
	    log.info(uploadFileNames);
	    log.info("2. rgister empDto:" + empDto);
		
//	    // File Upload + Emp 내용 --> Emp Insert
	    int emp_no = empService.register(empDto);
		System.out.println("emp/empInForm saveEmp emp_no->"+emp_no);
	    return  "redirect:list";
	    
	}

	@GetMapping("/list")
	public String listPage(EmpDto empDto , Model model) {
		System.out.println("emp/list Strart...");
		Long totalCountLong =  empService.totalEmp();	
		int totalCountInt = totalCountLong.intValue(); 
		System.out.println("1.EmpController list totalCount->"+totalCountInt);
		Paging page = new Paging(totalCountInt, empDto.getCurrentPage());

		// Parameter deptDto --> Page만 추가 Setting
		empDto.setStart(page.getStart());   // 시작시 1
		empDto.setEnd(page.getEnd());       // 시작시 10 
		
		System.out.println("2. EmpController list empDto->"+empDto);
		List<EmpDto> empDtoList = empService.empList(empDto);
  
		System.out.println("3. EmpController list empDtoList.size()=>" + empDtoList.size());
		System.out.println("5. EmpController list empDtoList=>" + empDtoList);

		model.addAttribute("totalCount", totalCountInt);
		model.addAttribute("empDtoList" , empDtoList);
		model.addAttribute("page"    , page);

		return "emp/list";
	}
	
	
	@GetMapping("/empDetail")
	public String deptDetail(EmpDto empDto  , Model model) {
		System.out.println("EmpController emp/empDetail Start...");
		System.out.println("1.EmpController emp/empDetail empDto->"+empDto);
		EmpDto empRtnDto = empService.getSingleEmp(empDto.getEmp_no());
		System.out.println("2.EmpController emp/empDetail empRtnDto->"+empRtnDto);
		model.addAttribute("empDto", empRtnDto);

		return "emp/empDetail";
	}


	@GetMapping("/modifyForm")
	public String modifyForm(EmpDto empDto  , Model model) {
		System.out.println("EmpController emp/modifyForm Start...");
		System.out.println("EmpController emp/modifyForm empDto->"+empDto);
		EmpDto empRtnDto  = empService.getSingleEmp(empDto.getEmp_no());
		// 부서선택을 combo Box로 제공하기 위함 
		List<DeptDto> deptDtoList = deptService.deptAllList();
		System.out.println("3. DeptController list listDept.size()=>" + deptDtoList.size());

		model.addAttribute("empDto",      empRtnDto);
		model.addAttribute("deptDtoList", deptDtoList);

		return "emp/empModifyForm";
	}	
	
	@PostMapping("/update")
	public String empUpdate(EmpDto empDto) {
		System.out.println("emp/empUpdate Strart...");
		System.out.println("emp/empUpdate empDto->"+empDto);
	
        // 1.수정하고자하는 old EmpDto
		EmpDto oldEmpDto = empService.getSingleEmp(empDto.getEmp_no());
		
		
	    System.out.println("1.EmpController 수정하고자하는 oldEmpDto->"+oldEmpDto);
	    //2. old EmpDto내 기존의 파일들 (데이터베이스에 존재하는 파일들 - 수정 과정에서 삭제되었을 수 있음)  
	    List<String> oldFileNames = oldEmpDto.getUploadFileNames();
	    System.out.println("2.EmpController empUpdate oldFileNames->"+oldFileNames);
	    
	    //3. 새로 업로드 해야 하는 파일들  
	    List<MultipartFile> files = empDto.getFiles();
	    System.out.println("3.EmpController empUpdate files.SIZES->"+files.size());
	    
	  
	
	    //4. 새로 업로드되어서 만들어진 파일 이름들
	    List<String> newUploadFileNames = fileUtil.saveFiles(files);
	    System.out.println("4.EmpController modify newUploadFileNames->"+newUploadFileNames);
	
	    //5.  화면에서 계속 유지된 파일들 (삭제된 것은 제거)
	    List<String> uploadedFileNames = empDto.getExistingUploadFileNames();
	    System.out.println("5.EmpController modify uploadedFileNames->"+uploadedFileNames);
	
	    //6. 유지되는 파일들  + 새로 업로드된 파일 이름들이 저장해야 하는 파일 목록이 됨  
	    if(newUploadFileNames != null && newUploadFileNames.size() > 0) {
	      uploadedFileNames.addAll(newUploadFileNames);
	      System.out.println("6.EmpController modify uploadedFileNames->"+uploadedFileNames);
	
	    }
	    // 7. DB 수정 작업 
	    // productService.modify(productDTO);
	    // 기본적으로 삭제여부는 false
	    // uploaded image Setting
	    empDto.setDel_status(false);
	    empDto.setUploadFileNames(uploadedFileNames);
	    System.out.println("8.EmpController modify empUpdate Beforee empDto->"+empDto);
	    EmpDto empUpdateDto = empService.empUpdate(empDto);
	    System.out.println("10.EmpController modify empUpdateDto->"+empUpdateDto);
	    // ----------------------------------------------------------------
	    // 8. 지워야 하는 파일 목록 찾기 & 삭제 
	    if(oldFileNames != null && oldFileNames.size() > 0){
	
	      //지워야 하는 파일 목록 찾기 
	      //예전 파일들 중에서 지워져야 하는 파일이름들 
	      List<String> removeFiles =  
	    		  oldFileNames
				      .stream()
				      .filter(fileName -> uploadedFileNames.indexOf(fileName) == -1)
				      .collect(Collectors.toList());
	
	      System.out.println("10.EmpController modify removeFiles->"+removeFiles);
	      //실제 파일 삭제 
	      fileUtil.deleteFiles(removeFiles);
		  // ----------------------------------------------------------------
	      System.out.println("11.EmpController modify removeFiles->"+removeFiles);
			
		}	
		return "redirect:list"; 

	}
	
	@GetMapping("/modifyLoginForm")
	public String modifyLoginForm(EmpDto empDto  , Model model) {
		System.out.println("EmpController emp/modifyLoginForm Start...");
		EmpDto empRtnDto  = empService.getSingleEmp(empDto.getEmp_no());
		System.out.println("EmpController emp/modifyLoginForm empDto->"+empDto);
		// 부서선택을 combo Box로 제공하기 위함 
		List<DeptDto> deptDtoList = deptService.deptAllList();
		System.out.println("3. DeptController list listDept.size()=>" + deptDtoList.size());

		model.addAttribute("empDto",      empRtnDto);
		model.addAttribute("deptDtoList", deptDtoList);

		return "emp/empModifyLoginForm";
	}	
	
	@PostMapping("/empLoginUpdate")
	public String empLoginUpdate(EmpDto empDto) {
		System.out.println("emp/empLoginUpdate Strart...");
		System.out.println("emp/empLoginUpdate empDto->"+empDto);
  	    
	    // 1. DB 수정 작업 
	    EmpDto empUpdateDto = empService.empLoginUpdate(empDto);
		// ----------------------------------------------------------------
	    System.out.println("1.EmpController modifyLoginForm empUpdateDto->"+empUpdateDto);

		return "redirect:list"; 

	}
	

	@GetMapping("/deleteEmp")
	public String deleteDept(EmpDto empDto  , Model model) {
		System.out.println("EmpController emp/deleteEmp Start...");
		System.out.println("EmpController emp/deleteEmp empDto->"+empDto);
		empService.deleteEmp(empDto.getEmp_no());

		return "redirect:list";
	}
	
	// Coding 진행 예정
	@ResponseBody
	@GetMapping("/checkEmpId")
	public Map<String, String> checkEmpId(EmpDto empDto, Model model) {
        System.out.println("EmpController emp/checkEmpId Start...");
        System.out.println("EmpController emp/checkEmpId empDto->"+empDto);
        
        // 중복된 사원번호가 있는지 확인(0/1)
        String isDuplicate = empService.checkEmpId(empDto.getEmp_id());
        System.out.println("EmpController emp/checkEmpId isDuplicate->"+isDuplicate);
        
        
        return Map.of("idDuplicate",isDuplicate);
    }

}
