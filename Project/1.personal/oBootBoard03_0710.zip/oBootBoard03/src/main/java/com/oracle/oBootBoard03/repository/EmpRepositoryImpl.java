package com.oracle.oBootBoard03.repository;

import java.util.List;

import com.oracle.oBootBoard03.domain.Emp;

public class EmpRepositoryImpl implements EmpRepository {

	@Override
	public List<Emp> findAllEmp() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Emp empSave(Emp emp) {
		// TODO Auto-generated method stub
		return null;
	}

}
