package com.oracle.oBootBoard03.service;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oracle.oBootBoard03.domain.Dept;
import com.oracle.oBootBoard03.dto.DeptDto;
import com.oracle.oBootBoard03.repository.DeptRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Transactional
@Log4j2
@RequiredArgsConstructor
public class DeptServiceImpl implements DeptService {

	//자동주입 대상은 final로 
    private final ModelMapper modelMapper;
    private final DeptRepository deptRepository;

	@Override
	public Long totalDept() {
		System.out.println("DeptServiceImpl dept/list Strart...");
		Long totalCount =  deptRepository.deptTotalcount();
		return totalCount;
	}

	@Override
	public List<DeptDto> deptList(DeptDto deptDto) {
	    List<DeptDto> deptRtnList = deptRepository.findPageDept(deptDto);
	    System.out.println("DeptServiceImpl deptList deptRtnList->"+deptRtnList);	
	    return deptRtnList;
	 }

	@Override
	public int deptSave(DeptDto deptDto) {
		log.info("DeptServiceImpl deptSave start deptDto->"+deptDto);
		Dept dept = modelMapper.map(deptDto, Dept.class);
		if(dept.getDept_gubun()==null) dept.changeDept_gubun(false);
		Dept saveDept = deptRepository.deptSave(dept);
		return saveDept.getDept_code();
	}

	@Override
	public DeptDto deptRead(DeptDto deptDto) {
		Dept dept = deptRepository.findById(deptDto.getDept_code());
		
		return entityToDto(dept);
	}
	
	private Dept dtoToEntity(DeptDto deptDto) {
		Dept dept = Dept.builder()
				.dept_code(deptDto.getDept_code())
				.dept_name(deptDto.getDept_name())
				.dept_captain(deptDto.getDept_captain())
				.dept_tel(deptDto.getDept_tel())
				.dept_loc(deptDto.getDept_loc())
				.in_date(deptDto.getIn_date())
				.dept_gubun(deptDto.getDept_gubun())
				.build();
		
		return dept;
	}

	private DeptDto entityToDto(Dept dept) {
		DeptDto deptDto = DeptDto.builder()
				.dept_code(dept.getDept_code())
				.dept_name(dept.getDept_name())
				.dept_captain(dept.getDept_captain())
				.dept_tel(dept.getDept_tel())
				.dept_loc(dept.getDept_loc())
				.in_date(dept.getIn_date())
				.dept_gubun(dept.getDept_gubun())
				.build();
		
		return deptDto;
	}

	@Override
	public void deptDelete(DeptDto deptDto) {
		deptRepository.deptDelete(deptDto.getDept_code());
	}

	@Override
	public DeptDto deptModify(DeptDto deptDto) {
		Dept dept = deptRepository.deptUpdate(deptDto);
		
		return entityToDto(dept);
	}
}
