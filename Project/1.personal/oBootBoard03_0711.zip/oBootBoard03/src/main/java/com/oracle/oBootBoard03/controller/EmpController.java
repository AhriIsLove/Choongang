package com.oracle.oBootBoard03.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.oracle.oBootBoard03.dto.EmpDto;
import com.oracle.oBootBoard03.service.EmpService;
import com.oracle.oBootBoard03.service.Paging;
import com.oracle.oBootBoard03.util.CustomFileUtil;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/emp")
@RequiredArgsConstructor
public class EmpController {
	private final EmpService empService;
	private final CustomFileUtil fileUtil;

	@GetMapping("/list")
	public String listPage(EmpDto empDto, Model model) {
		System.out.println("emp/list Strart...");

		int totalCount = empService.totalEmp();
		System.out.println("1.empController list totalCount->" + totalCount);
		Paging page = new Paging(totalCount, empDto.getCurrentPage());

		// Parameter empDto --> Page만 추가 Setting
		empDto.setStart(page.getStart()); // 시작시 1
		empDto.setEnd(page.getEnd()); // 시작시 10

		System.out.println("2. empController list empDto->" + empDto);
		List<EmpDto> empDtoList = empService.empList(empDto);
		System.out.println("3. empController list listemp.size()=>" + empDtoList.size());

		model.addAttribute("totalCount", totalCount);
		model.addAttribute("empDtoList", empDtoList);
		model.addAttribute("page", page);

		return "emp/list";
	}

	@GetMapping("/empInForm")
	public String empInForm() {
		System.out.println("emp/empInForm Strart...");

		return "emp/empInForm";
	}

	@PostMapping("saveEmp")
	public String saveEmp(EmpDto empDto) {
		System.out.println("emp/saveEmp empDto->" + empDto);

		List<MultipartFile> files = empDto.getFiles();

		// File Upload
		List<String> uploadFileNames = fileUtil.saveFiles(files);
		empDto.setUploadFileNames(uploadFileNames);

		// File Upload + Product 내용 --> tbl_product Insert
		int empno = empService.empSave(empDto);

		return "redirect:list";
	}

	@GetMapping("/empDetail")
	public String empDetail(EmpDto empDto, Model model) {
		System.out.println("empDetail empDto->" + empDto);
		EmpDto empRtnDto = empService.getSingleEmp(empDto.getEmp_no());
		model.addAttribute("empDto", empRtnDto);

		return "emp/empDetail";
	}

	@GetMapping("/modifyForm")
	public String modifyForm(EmpDto empDto, Model model) {
		System.out.println("modifyForm deptDto->" + empDto);
		EmpDto empRtnDto = empService.getSingleEmp(empDto.getEmp_no());
		model.addAttribute("empDto", empRtnDto);

		return "emp/modifyForm";
	}

	@PostMapping("update")
	public String deptUpdate(EmpDto empDto) {
		System.out.println("startstartstartstartstartstartstartstart");

		// 기존의 파일들(1u,2u,3u)
		EmpDto oldEmpDto = empService.getSingleEmp(empDto.getEmp_no());
		List<String> oldFileNames = oldEmpDto.getUploadFileNames();

		// 새로 업로드 해야 하는 파일들(3,4,5)
		List<MultipartFile> files = empDto.getFiles();

		// 새로 업로드 되어서 만들어진 파일 이름들(3u,4u,5u)
		List<String> currentUploadFileNames = fileUtil.saveFiles(files);

		// 유지되는 파일들() : view에서 uploadFileNames에 값을 넣어준 상태로 보내준다면 있을것임(3u)
		List<String> uploadedFileNames = empDto.getUploadFileNames();
		// + 새로 업로드된 파일 이름들(3u,4u,5u)
		if (currentUploadFileNames != null && currentUploadFileNames.size() > 0) {
			// addAll : 중복값 허용
			uploadedFileNames.addAll(currentUploadFileNames);
		}

		// DB 수정
		EmpDto empUpdateDto = empService.empUpdate(empDto);

		System.out.println("oldFileNames" + oldFileNames.size());
		// 지워야 하는 파일 목록 찾기(1u,2u,3u)
		// 유지되는 파일들이 view에서 정해줘야 하는데 없으면 old의 3u와 uploaded의 3u는 다른 3u이다.
		if (oldFileNames != null && oldFileNames.size() > 0) {
			// 기존의 파일들중에(u1,2u,3u)
			List<String> removeFiles = oldFileNames.stream()
					// 이미 업로드된 파일들을 못찾으면 -1로 삭제대상으로 지정(3u,4u,5u)
					.filter(fileName -> uploadedFileNames.indexOf(fileName) == -1).collect(Collectors.toList());

			// 삭제(1u,2u)
			fileUtil.deletFiles(removeFiles);
		}
		
		System.out.println("endendendendendendendendendendendendendendendendendend");

		return "redirect:list";
	}

	@GetMapping("/deleteEmp")
	public String deleteEmp(EmpDto empDto, Model model) {
		System.out.println("DeptController dept/deleteDept deptDto->" + empDto);
		empService.deleteEmp(empDto.getEmp_no());

		return "redirect:list";
	}
	
	@GetMapping("read")
	public Map<Integer, String> read(){
		Map<Integer, String> map = new HashMap<Integer, String>();
		
		//해당 부서의 모든 사원을 가져온다.
//		List<EmpDto> empDtoList = empService.empList(empDto);
		
		return map;
	}
}
