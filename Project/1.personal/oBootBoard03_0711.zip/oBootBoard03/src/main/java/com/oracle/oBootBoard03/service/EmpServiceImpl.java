package com.oracle.oBootBoard03.service;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.oracle.oBootBoard03.domain.Dept;
import com.oracle.oBootBoard03.domain.Emp;
import com.oracle.oBootBoard03.domain.EmpImage;
import com.oracle.oBootBoard03.dto.DeptDto;
import com.oracle.oBootBoard03.dto.EmpDto;
import com.oracle.oBootBoard03.repository.EmpRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Service
@Transactional
@Log4j2
@RequiredArgsConstructor
public class EmpServiceImpl implements EmpService {

	//자동주입 대상은 final로 
    private final ModelMapper modelMapper;
    private final EmpRepository empRepository;

	@Override
	public int totalEmp() {
		System.out.println("EmpServiceImpl emp/list Strart...");
		int totalCount =  empRepository.empTotalcount();
		return totalCount;
	}

	@Override
	public List<EmpDto> empList(EmpDto empDto) {
	    List<EmpDto> empRtnList = empRepository.findPageEmp(empDto);
	    System.out.println("EmpServiceImpl deptList deptRtnList->"+empRtnList);	
	    return empRtnList;
	 }

	@Override
	public int empSave(EmpDto empDto) {
		Emp emp = modelMapper.map(empDto, Emp.class);
		if(emp.getDel_status()==null) emp.changeDel_status(false);
		
		// 업로드 처리가 끝난 파일들의 이름 리스트
		List<String> uploadFileNames = empDto.getUploadFileNames();
		if(uploadFileNames == null) return emp.getEmp_no();
		else {
			// Entity에게 uploadName을 넘겨중 --> List<ProductImage> imageList 누적
			uploadFileNames.stream().forEach(uploadFileName -> {
				emp.addImageString(uploadFileName);
			});
		}
		
		Emp saveEmp = empRepository.empSave(emp);
		return saveEmp.getEmp_no();
	}

	@Override
	public EmpDto getSingleEmp(int emp_no) {
		// TODO Auto-generated method stub
		Emp emp = empRepository.findById(emp_no);
		System.out.println("getSingleEmp emp->"+emp);
		EmpDto empDto = modelMapper.map(emp, EmpDto.class );
		
		List<EmpImage> imageList = emp.getImageList();
		if(imageList == null || imageList.size() == 0) return empDto;
		else {
			List<String> fileNameList = imageList.stream()
					.map(empImage->empImage.getFilename()).toList();
			
			empDto.setUploadFileNames(fileNameList);
		}
		
		return empDto;
	}

	@Override
	public EmpDto empUpdate(EmpDto empDto) {
		Optional<Emp> maybeEmp = empRepository.findById2(empDto.getEmp_no());
		Emp emp = maybeEmp.orElseThrow();
		emp.changeEmpId(empDto.getEmp_id());
		emp.changeEmp_name(empDto.getEmp_name());
		emp.changeEmp_password(empDto.getEmp_password());
		emp.changeEmail(empDto.getEmail());
		emp.changeEmp_tel(empDto.getEmp_tel());
		emp.changeSal(empDto.getSal());
//		emp.changeDel_status(empDto.getDel_status());
		emp.changeDept_code(empDto.getDept_code());
	    System.out.println("DeptServiceImpl modify emp->"+emp);

		//이미지 목록 삭제
	    emp.clearList();
		
		//이미지 목록 생성
		List<String> uploadFileNames = empDto.getUploadFileNames();
		if(uploadFileNames != null && uploadFileNames.size() > 0) {
			uploadFileNames.stream()
			.forEach(uploadName -> {
				emp.addImageString(uploadName);
			});
		}
		
	    Emp empUpdateEntity = empRepository.empSave(emp);
	    EmpDto empRtnDto = modelMapper.map(empUpdateEntity, EmpDto.class );
		return empRtnDto;
	}

	@Override
	public void deleteEmp(int emp_no) {
	    System.out.println("DeptServiceImpl deleteDept dept_code->"+emp_no);
		empRepository.deleteById(emp_no);
		
	}
}
