package com.oracle.oBootBoard03.controller;

import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.oracle.oBootBoard03.util.CustomFileUtil;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
// Main , Login , 비밀번호 찾기
public class MainController {
	private final CustomFileUtil fileUtil;
	
	@GetMapping("/main")
	public String mainPage() {
		System.out.println("mainPage Strart...");
		return "main";
	}

	@GetMapping("/upload/{fileName}")
	public ResponseEntity<Resource> viewFileGET(@PathVariable(name="fileName") String fileName){
		System.out.println("fileName123" + fileName);
		
		return fileUtil.getFile(fileName);
	}
	
}
