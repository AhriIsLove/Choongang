package com.oracle.oBootBoard03.repository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.oracle.oBootBoard03.domain.Dept;
import com.oracle.oBootBoard03.domain.Emp;
import com.oracle.oBootBoard03.dto.EmpDto;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.persistence.TypedQuery;
import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class EmpRepositoryImpl implements EmpRepository {
	private final EntityManager em;

	@Override
	public List<Emp> findAllEmp() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Emp empSave(Emp emp) {
		System.out.println("empSave emp->"+emp);
		em.persist(emp);
		return emp;
	}

	@Override
	public int empTotalcount() {
		TypedQuery<Long> query = 
				em.createQuery("select count(e) from Emp e where del_status = false", Long.class); // Dept.class 대신 Long.class
		Long totalCount = query.getSingleResult();
		int totalCountInt = totalCount.intValue(); 

		return totalCountInt;
	}

	@Override
	public List<EmpDto> findPageEmp(EmpDto empDto) {
		// JPQL 쿼리
	    // Oracle 11g ROWNUM을 이용한 페이징 네이티브 쿼리
	    // d1_0 대신 dept_code, dept_captain 등 실제 컬럼명 사용 (엔티티 필드명이 아님!)
	    // SELECT 절에 엔티티의 모든 컬럼을 명시하거나, 엔티티 매핑 정보를 활용해야 함
	    // 여기서는 Dept 엔티티의 모든 컬럼을 명시한다고 가정
	    String nativeSql = "SELECT emp_no, emp_name, email, emp_tel, sal, emp_pic, dept_code, in_date, del_status, emp_password, emp_id " // 실제 컬럼명들을 나열	                     
	    				 + "FROM ( "
	                     + "    SELECT ROWNUM rn, a.* "
	                     + "    FROM ( "
	                     + "        SELECT emp_no, emp_name, email, emp_tel, sal, emp_pic, dept_code, in_date, del_status, emp_password, emp_id " // 실제 컬럼명들을 나열
	                     + "        FROM   Emp " // 테이블명은 엔티티명이 아닌 실제 DB 테이블명
	                     + "        WHERE  del_status = 0"
	                     + "        ORDER BY emp_no "
	                     + "    ) a "
	                     + ") "
	                     + "WHERE rn BETWEEN :start AND :end";

	    // em.createNativeQuery()를 사용하고, 결과를 Dept.class로 매핑하도록 지정
	    Query query = em.createNativeQuery(nativeSql, Emp.class); // 두 번째 인자로 엔티티 클래스를 주면 자동으로 매핑 시도

	    // :start 파라미터에 값 넣기
	    query.setParameter("start", empDto.getStart());
	    // :end 파라미터에 값 넣기
	    query.setParameter("end", empDto.getEnd());

	    
	    List<Emp> empEntityList = query.getResultList();
	    System.out.println("DeptRepositoryImplfindPageDept deptEntityList->"+empEntityList);

        // 2. Stream API를 사용하여 Entity List를 DTO List로 변환
        List<EmpDto> empDtoList = empEntityList.stream()
								                // 각 dept 엔티티를 deptDto 객체로 매핑 (변환)
								                // deptDto::new는 deptDto(Dept dept) 생성자를 호출하는 것과 같아.
								                //.map(DeptDto::new)
								                .map(emp->new EmpDto(emp))
								                // 매핑된 DTO 객체들을 List로 다시 수집
        		                               .collect(Collectors.toList());
	    
	    System.out.println("DeptRepositoryImplfindPageDept deptDtoList->"+empDtoList);
	    
	    // 쿼리 실행 및 결과 반환
	    return empDtoList;	
	}

	@Override
	public Emp findById(int emp_no) {
		Emp emp = em.find(Emp.class, emp_no);
		return emp;
	}

	@Override
	public Optional<Emp> findById2(int emp_no) {
		// 1. 먼저 em.find()로 엔티티를 조회
		Emp foundEmp = em.find(Emp.class, emp_no);

		// 2. 조회된 엔티티를 Optional.ofNullable()로 감싸기
		Optional<Emp> empOptional = Optional.ofNullable(foundEmp);

		return empOptional;
	}

	@Override
	public void deleteById(int emp_no) {
		Emp emp = em.find(Emp.class, emp_no);
		emp.changeDel_status(true);
	}

}
